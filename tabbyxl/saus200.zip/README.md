This case study demonstrates how the software platform can be applied to extract data from spreadsheet tables of government statistics in real-world settings.

## Contents

- [Overview](#overview)
- [Ruleset](#ruleset)
- [Steps to reproduce](#steps-to-reproduce)
  - [Deploy software and data](#deploy-software-and-data)
  - [Generate source code of Extractor](#generate-source-code-of-extractor)
  - [Build Extractor](#build-extractor)
  - [Correct source tables](#correct-source-tables)
  - [Extract data from tables](#extract-data-from-tables)
  - [Evaluate results](#evaluate-results)

## Overview

We demonstrate the applicability of the software platform for extracting data items and their relationships from spreadsheet tables of SAUS (The 2010 Statistical Abstract of the United States) corpora. Note, many of these tables have a complex structure that prevents statistical facts containing in them be indexing and querying directly. (See a sample of such structure in the picture below).

<p><img src="https://github.com/tabbydoc/images/blob/master/tabbyxl/example_saus_sample1.svg" alt="The table fragment from SAUS corpora" width="600"/></p>

Originally, 1369 of SAUS tables was collected and published by Chen and Cafarella as a part of Senbazuru project [1]. Afterward George Nagy randomly selected 200 tables of them and published this subset [2]. This example aims to transforming all 200 tables of Nagy's subset to a canonical form. We made minor changes in them by removing empty columns and hidden columns that duplicate other visible columns. The modified subset is availbale as a part of this example [3].

### References
1. SAUS, http://dbgroup.eecs.umich.edu/project/sheets/datasets.html
2. Nagy's subset http://tc11.cvc.uab.es/datasets/Troy_200_1
3. Modified subset, https://github.com/tabbydoc/examples/blob/master/tabbyxl/example_saus/data/tables.xlsx

## Ruleset

The ruleset consists of 18 CRL-rules for analysis and interpretation of SAUS tables:

 - Rule #1 removes next line characters from the textual content of a
   cell. 
 - Rules #2-3 creates and categorize a label in a cut-in cell.
 - Rules #4-5 creates and categorize a label in a stub-head cell.
 - Rule #6 creates and categorize a label in a cut-in cell.
 - Rule #7 creates and categorize a label in a head cell. 
 - Rule #8 creates an entry in a body cell. 
 - Rules #9-13 create a parent-child pair from two labels in stub cells (each rule for a for a separate layout trick used in a stub).
  - Rule #14 associates a label originated from a stub cell with an entry. 
  - Rule #15 creates a parent-child pair from two labels in head cells. 
  - Rule #16 creates a parent-child pair from two labels in cut-in cells. 
  - Rule #17 associates a label originated from a head cell with an entry.
  - Rule #18 associates a label originated from a cut-in cell with an entry.

```
import static ru.icc.td.tabbyxl.model.style.HorzAlignment.*

rule #1
  when
    cell c: !blank, t: text
  then
    set text t.replaceAll("\\n", "") to c
end

rule #2
  when
    cell c: cl == 1, rt > 1, text.matches("[Uu]nit indicator")
  then
    set tag "HEAD1" to c
    new label c
    set category c.tag to c.label
end

rule #3
  when
    cell c1: tag == "HEAD1"
    cell c2: cl > 1, rt == c1.rt, !blank, !tagged
  then
    set tag "HEAD1" to c2
    new label c2
    set category c2.tag to c2.label
end

rule #4
  when
    cell c: cl == 1, !blank, !tagged, !text.matches("(\\u005c[0-9]+)|([Uu]nit indicator)")
  then
    set tag "STUB" to c
    new label c
    set category c.tag to c.label
end

rule #5
  when
    cell corner: cl == 1, rt == 1
    cell c1: cl > corner.cr, rt == corner.rt, rb == corner.rb, text.matches(".*(([Uu]nit)|([Pp]ost [Oo]ffice)|([Cc]ode)|(CODE)|([Ss]tation)|(ANSI)|(ABBREVIATION)|([Aa]bbreviation)|([Pp]resident)|([Ff]ips)|(FIPS)).*")
    cell c2: cl == c1.cl, cr == c1.cr, !blank, !tagged
  then
    set tag "STUB" + (c1.cl - 1) to c2
    new label c2
    set category c2.tag to c2.label
end

rule #6
  when
    cell corner: cl == 1, rt == 1
    cell c1: cl > corner.cr, rb <= corner.rb, !blank, !tagged
    cell c2: cl > corner.cr, rt == c1.rb + 1, rb <= corner.rb, (cl <= c1.cl && c1.cr < cr ) || ( cl < c1.cl && c1.cr <= cr ), !blank, !tagged
  then
    set tag "HEAD1" to c2
    new label c2
    set category c2.tag to c2.label
end

rule #7
  when
    cell corner: cl == 1, rt == 1
    cell c: cl > corner.cr, !blank, !tagged, rt >= corner.rt, rb <= corner.rb
  then
    set tag "HEAD" to c
    new label c
    set category c.tag to c.label
end

rule #8
  when
    cell c1: cl == 1, rt == 1
    cell c2: cl > c1.cr, rt > c1.rb, tag == null, !blank, !text.matches("\\u005c[0-9]+")
  then
    set tag "DATA" to c2
    new entry c2
end

rule #9
  when
    label l1: category.name.equals("STUB"), cell.rt > 1, !cell.style.font.bold
    label l2: category.name.equals("STUB"), !cell.style.font.bold, cell.rt > l1.cell.rb, cell.indent > l1.cell.indent
    no labels: category.name.equals("STUB"), !cell.style.font.bold, cell.rt > l1.cell.rb, cell.rb < l2.cell.rt, cell.indent >= l1.cell.indent, cell.indent < l2.cell.indent
    no cells: cl == 1, rt > l1.cell.rb, rb < l2.cell.rt, blank, !tagged
  then
    set parent l1 to l2
end

rule #10
  when
    label l1: category.name.equals("STUB"), cell.rt > 1, cell.style.font.bold, cell.indent > 0, !cell.text.matches("([Uu]nited [Ss]tates)|([Tt]otal)")
    label l2: category.name.equals("STUB"), !cell.style.font.bold, cell.rt > l1.cell.rb, cell.indent == 0, parent == null
    no labels: category.name.equals("STUB"), cell.style.font.bold, cell.rt > l1.cell.rb, cell.rb < l2.cell.rt, cell.indent == l1.cell.indent
  then
    set parent l1 to l2
end

rule #11
  when
    label l1: category.name.equals("STUB"), cell.rt > 1, cell.style.horzAlignment == CENTER
    label l2: category.name.equals("STUB"), cell.rt > l1.cell.rb, cell.style.horzAlignment == GENERAL || cell.style.horzAlignment == LEFT, parent == null
    no labels: category.name.equals("STUB"), cell.rt > l1.cell.rb, cell.rb < l2.cell.rt, cell.style.horzAlignment == CENTER
  then
    set parent l1 to l2
end

rule #12
  when
    label l1: category.name.equals("STUB"), cell.rt == 1
    label l2: category.name.equals("STUB"), cell.rt > 1, parent == null
  then
    set parent l1 to l2
end

rule #13
  when
    label l1: category.name.matches("STUB([0-9])"), cell.rt == 1
    label l2: category.name.equals(l1.category.name), cell.rt > l1.cell.rb
  then
    set parent l1 to l2
end

rule #14
  when
    entry e
    label l: category.name.matches("STUB[0-9]?"), cell.rt == e.cell.rt, cell.rb == e.cell.rb
  then
    add label l to e
end

rule #15
  when
    label l1: category.name.equals("HEAD")
    label l2: category.name.equals("HEAD"), cell.rt > l1.cell.rb, cell.cl >= l1.cell.cl, cell.cr <= l1.cell.cr
    no labels: category.name.equals("HEAD"), cell.cl <= l2.cell.cl, cell.cr >= l2.cell.cr, cell.rb < l2.cell.rt, cell.rt > l1.cell.rb
  then
    set parent l1 to l2
end

rule #16
  when
    label l1: category.name.equals("HEAD1"), cell.cl == 1
    label l2: category.name.equals("HEAD1"), cell.cl > 1
  then
    set parent l1 to l2
end

rule #17
  when
    entry e
    label l: category.name.equals("HEAD"), cell.cl <= e.cell.cl, cell.cr >= e.cell.cr
    no labels: category.name.equals("HEAD"), cell.cl <= e.cell.cl, cell.cr >= e.cell.cr, cell.rt > l.cell.rb
  then
    add label l to e
end

rule #18
  when
    entry e
    label l: category.name.equals("HEAD1"), cell.cl <= e.cell.cl, cell.cr >= e.cell.cr
  then
    add label l to e
end
```
*[Download this ruleset](https://github.com/tabbydoc/examples/blob/master/tabbyxl/example_saus/rules/rules.crl)*

## Steps to reproduce

<p><img src="https://github.com/tabbydoc/images/blob/master/tabbyxl/example_saus_workflow.svg" alt="The workflow on reproducing the example" width="600"/></p>

### Deploy software and data

Download and install [Java SE Development Kit 8](http://www.oracle.com/technetwork/java/javase/downloads) or more.

> Note that `TabbyXL` uses Java compiler included in JDK to compile Java code automatically generated from CRL rules with `CRL2J` option. This requires to use JDK, not JRE.

Download and install [Apache Maven](https://maven.apache.org).

> Note that this is needed to build the executable JAR file from the generated source code.

Download and unpack [zip archive](https://github.com/tabbydoc/examples/blob/master/tabbyxl/saus200.zip) that contains the data files of this example into your directory.

Download and unpack [`tabbyxl-1.1.1.zip`](https://github.com/tabbydoc/tabbyxl/releases/tag/v1.1.1) into this directory.

> Note that you can also build `TabbyXL-1.1.1-jar-with-dependencies.jar` (the required executable JAR file with dependencies) from [the source code](https://github.com/tabbydoc/tabbyxl/releases/tag/v1.1.1) ([read the instruction on building with Apache Maven](https://github.com/tabbydoc/tabbyxl/blob/master/README.md#building-with-apache-maven)).

As a result you will get the following structure of your directory:
```
+-- data/
�   +-- tables_original.xlsx
�   L-- tables_reference.xlsx
+-- rules/
�   L-- rules.crl
+-- my_extractor/
+-- extracted/
�   +-- from_original_tables/
�   +-- from_autocorrected_tables/
�   L-- from_reference_tables/
L-- TabbyXL-1.1.1.jar
```

Change to your directory that contains the unpacked data and `TabbyXL`
```bash
cd <path to your directory>
```

### Generate source code of Extractor

To generate a Maven project containing the source code generated from the CRL ruleset, run the executable JAR with the following command:
```bash
java -cp -cp TabbyXL-1.1.1.jar ru.icc.td.tabbyxl.MvnGen rules/rules.crl my_extractor
```

> Please, check that you run `java` included in JDK. You also can try to use `"%JAVA_HOME%/bin/java"` instead of `java` as follows:
```bash
"%JAVA_HOME%/bin/java" -cp TabbyXL-1.1.1.jar ru.icc.td.tabbyxl.MvnGen rules/rules.crl my_extractor
```

See the created project in the output directory `my_extractor`.

The created project has the directory structure in accordance with Maven conventions as follows:
```
+-- src/
�   L-- main/
�       L-- java/
�           L-- generated/
�           �   +-- TableConsumer1.java <generated from Rule1>
�           �   +-- ...
�           �   L-- TableConsumer18.java <generated from Rule18>
�           L-- SpreadsheetDataExtractorApp.java <Main-class>
L-- pom.xml <POM file>
```

> Note that each rule of a source ruleset is translated from CRL to a separate Java class (`*.java` file). All generated classes implement `Consumer<T>`, a common functional interface provided by Java that represents a procedure with a single argument. Each class has a single method, `accept(T t)`, that performs an operation corresponding to a source rule on the given table. 

### Build Extractor

The created Maven project can be built by Apache Maven.

Go the project directory to `my_extractor` as follows:
```bash
cd my_extractor
```
Run Maven to get an executable application (JAR file) as follows:
```bash
mvn clean install
```
See the results of the building executable application (JAR file) in the direcory `my_extractor/target`

### Correct source tables

�hange to your directory that contains the unpacked data and `TabbyXL`:
```bash
cd ..
```

To correct the source tables by HeadRecog utility, run `TabbyXL` with the following command:
```bash
java -Xmx1024M -cp TabbyXL-1.1.1.jar  ru.icc.td.tabbyxl.HeadRecog -input data/tables_original.xlsx -output data/tables_autocorrected.xlsx
```

As a result, the corrected tables should be written in the workbook `data/tables_autocorrected.xlsx`.

When you see something like this instead of the result 
```bash
Exception in thread "main" java.lang.OutOfMemoryError: Java heap space
```
Then you should prefer to use `java` included in JDK as follows:
```bash
"%JAVA_HOME%/bin/java" -cp TabbyXL-1.1.1.jar  ru.icc.td.tabbyxl.HeadRecog -input data/tables_original.xlsx -output data/tables_autocorrected.xlsx
```
Or you can configure more memory for your JVM by setting `-Xmx`-option.

### Extract data from tables

#### Case 1. Source tables without correction

To extract data from not corrected tables, run `MyExtractor` (the executable JAR file with dependencies) as follows:
```bash
java -Xmx1024M -jar my_extractor/target/MyExtractor-1.0-jar-with-dependencies.jar data/tables_original.xlsx extracted/from_original_tables
```

####  Case 2. Source tables with auto-correction

To extract data from tables corrected automatically by HeadRecog, run `MyExtractor` (the executable JAR file with dependencies) as follows:
```bash
java -Xmx1024M -jar my_extractor/target/MyExtractor-1.0-jar-with-dependencies.jar  data/tables_autocorrected.xlsx extracted/from_autocorrected_tables
```

#### Case 3. Source tables with manual correction

To extract data from tables corrected manually by experts, run `MyExtractor` (the executable JAR file with dependencies) as follows:
```bash
java -Xmx1024M -jar my_extractor/target/MyExtractor-1.0-jar-with-dependencies.jar data/tables_reference.xlsx extracted/from_reference_tables
```

See results in `results_case3.log` file.

### Evaluate results

> Note, that you should change to your directory that contains the
> unpacked data and `TabbyXL`
```bash
cd <path to your directory>
```

#### Case 1. Source tables without correction

To evaluate the results of data extraction from not corrected tables, run `TabbyXL` with the following command:
```bash
java -cp TabbyXL-1.1.1.jar ru.icc.td.tabbyxl.evaluation.Evaluator extracted/from_original_tables gt >> eval_case1.log
```

You can see the following SUMMARY OF RESULTS in `eval.log`:

|           |`entries`                 |`labels`               |`entry-label pairs`      |`label-label pairs`|
|-----------|--------------------------|-----------------------|-------------------------|-------------------------|
|`recall`   |`0.8783031 (120122/136766)` |`0.7543929 (15155/20089)`|`0.6896431 (267236/387499)`|`0.6391954 (11471/17946)`
|`precision`|`0.81885546 (120122/146695)`|`0.8206531 (15155/18467)`|`0.76679796 (267236/348509)`|`0.70069027 (11471/16371)`

####  Case 2. Source tables with auto-correction

To evaluate the results of data extraction from tables corrected automatically by using HeadRecog, run `TabbyXL` with the following command:
```bash
java -cp TabbyXL-1.1.1.jar ru.icc.td.tabbyxl.evaluation.Evaluator extracted/from_autocorrected_tables gt >> eval_case2.log
```

You can see the following SUMMARY OF RESULTS in `eval.log`:
|           |`entries`                 |`labels`               |`entry-label pairs`      |`label-label pairs`|
|-----------|--------------------------|-----------------------|-------------------------|-------------------------|
|`recall`   |`0.8790854 (120229/136766)` |`0.8616656 (17310/20089)`|`0.8378835 (324679/387499)`|`0.7556559 (13561/17946)`
|`precision`|`0.83098793 (120229/144682)`|`0.85714287 (17310/20195))`|`0.81081575 (324679/400435)`|`0.7716074 (13561/17575)`

#### Case 3. Source tables with manual correction

To evaluate the results of data extraction from tables corrected manually by experts, run `TabbyXL` with the following command:
```bash
java -cp TabbyXL-1.1.1.jar ru.icc.td.tabbyxl.evaluation.Evaluator extracted/from_reference_tables gt >> eval_case3.log
```

You can see the following SUMMARY OF RESULTS in `eval.log`:
|           |`entries`                 |`labels`               |`entry-label pairs`      |`label-label pairs`|
|-----------|--------------------------|-----------------------|-------------------------|-------------------------|
|`recall`   |`0.9928272 (135785/136766)` |`0.9360346 (18804/20089)`|`0.95489794 (370022/387499)`|`0.83907276 (15058/17946)`
|`precision`|`0.9419832 (135785/144148)`|`0.9446398 (18804/19906)`|`0.9274501 (370022/398967)`|`0.863566 (15058/17437)`
